
function calculateTotalCharges()
{
	var no_of_units=parseInt(document.electricity_bill.units.value);
	var total_amount=(no_of_units*2.96);
	
	alert("The total amount of the bill is  "+total_amount);
	if (no_of_units <100)
	{
		alert("The total amount of the bill is  "+total_amount);
	}
	
	
}
